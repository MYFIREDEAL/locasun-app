# 🎨 Diagramme de la Base de Données

## Architecture Complète

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         SUPABASE DATABASE                               │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          AUTH.USERS (Supabase Auth)                      │
│  ┌────────────────────────────────────────────────────────────┐          │
│  │ • UUID (id)                                                │          │
│  │ • email                                                    │          │
│  │ • password (encrypted)                                     │          │
│  │ • created_at                                               │          │
│  └────────────────────────────────────────────────────────────┘          │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ (1:1)
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                              PUBLIC.USERS                                │
│  ┌────────────────────────────────────────────────────────────┐          │
│  │ • id (UUID) → auth.users(id)                              │          │
│  │ • name                                                     │          │
│  │ • email                                                    │          │
│  │ • role (Global Admin, Manager, Commercial, Client)        │          │
│  │ • manager_id (UUID) → users(id)                           │          │
│  │ • access_rights (JSONB)                                   │          │
│  │ • avatar_url                                              │          │
│  │ • phone                                                    │          │
│  └────────────────────────────────────────────────────────────┘          │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
                    ▼               ▼               ▼
          ┌─────────────────┐  ┌─────────────┐  ┌──────────────┐
          │   PROSPECTS     │  │ APPOINTMENTS│  │    CALLS     │
          └─────────────────┘  └─────────────┘  └──────────────┘
                    │
          ┌─────────┼─────────┐
          ▼         ▼         ▼
    ┌─────────┐ ┌────────┐ ┌──────────────┐
    │  TASKS  │ │ CHAT   │ │ PROJECT_INFO │
    └─────────┘ └────────┘ └──────────────┘


═══════════════════════════════════════════════════════════════════════════
DÉTAIL DES TABLES
═══════════════════════════════════════════════════════════════════════════

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                          PUBLIC.PROSPECTS                             ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  id                    UUID (PK)                                     ┃
┃  name                  TEXT                                          ┃
┃  email                 TEXT                                          ┃
┃  phone                 TEXT                                          ┃
┃  company_name          TEXT                                          ┃
┃  address               TEXT                                          ┃
┃  owner_id              UUID (FK → users.id) 🔗                       ┃
┃  status                TEXT (Intéressé, Lead, Qualified...)          ┃
┃  tags                  TEXT[] (ACC, Centrale, Autonomie...)          ┃
┃  affiliate_name        TEXT                                          ┃
┃  has_appointment       BOOLEAN                                       ┃
┃  created_at            TIMESTAMPTZ                                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                                │
                ┌───────────────┼──────────────────┐
                ▼               ▼                  ▼
┌──────────────────────┐ ┌──────────────────┐ ┌─────────────────────┐
│   APPOINTMENTS       │ │      CALLS       │ │       TASKS         │
├──────────────────────┤ ├──────────────────┤ ├─────────────────────┤
│ • id (UUID)          │ │ • id (UUID)      │ │ • id (UUID)         │
│ • title              │ │ • name           │ │ • text              │
│ • start_time         │ │ • date           │ │ • date              │
│ • end_time           │ │ • time           │ │ • contact_id (FK)   │
│ • contact_id (FK) 🔗 │ │ • contact_id 🔗  │ │ • assigned_user 🔗  │
│ • assigned_user 🔗   │ │ • assigned_usr 🔗│ │ • done (BOOLEAN)    │
│ • project_id         │ │ • status         │ │ • notes             │
│ • step               │ │ • notes          │ └─────────────────────┘
│ • status             │ └──────────────────┘
│ • share (BOOLEAN)    │
│ • notes              │
└──────────────────────┘


┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                        PUBLIC.CHAT_MESSAGES                           ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  id                    UUID (PK)                                     ┃
┃  prospect_id           UUID (FK → prospects.id) 🔗                   ┃
┃  project_type          TEXT (ACC, Centrale...)                       ┃
┃  sender                TEXT (client, admin, pro)                     ┃
┃  text                  TEXT                                          ┃
┃  file                  JSONB {name, size, type, url}                 ┃
┃  form_id               TEXT                                          ┃
┃  completed_form_id     TEXT                                          ┃
┃  prompt_id             TEXT                                          ┃
┃  step_index            INTEGER                                       ┃
┃  read                  BOOLEAN                                       ┃
┃  created_at            TIMESTAMPTZ                                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    PUBLIC.PROJECT_STEPS_STATUS                        ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  id                    UUID (PK)                                     ┃
┃  prospect_id           UUID (FK → prospects.id) 🔗                   ┃
┃  project_type          TEXT (ACC, Centrale...)                       ┃
┃  steps                 JSONB                                         ┃
┃                        [{name, status, icon}, ...]                   ┃
┃  created_at            TIMESTAMPTZ                                   ┃
┃  updated_at            TIMESTAMPTZ                                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                      PUBLIC.PROJECT_INFOS                             ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  id                    UUID (PK)                                     ┃
┃  prospect_id           UUID (FK → prospects.id) 🔗                   ┃
┃  project_type          TEXT (ACC, Centrale...)                       ┃
┃  data                  JSONB                                         ┃
┃                        {ribFile, documents, surface, ...}            ┃
┃  created_at            TIMESTAMPTZ                                   ┃
┃  updated_at            TIMESTAMPTZ                                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                         PUBLIC.PROJECTS                               ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  id                    UUID (PK)                                     ┃
┃  type                  TEXT (ACC, Centrale, Autonomie...)            ┃
┃  title                 TEXT                                          ┃
┃  client_title          TEXT                                          ┃
┃  icon                  TEXT (emoji)                                  ┃
┃  color                 TEXT                                          ┃
┃  is_public             BOOLEAN                                       ┃
┃  steps                 JSONB                                         ┃
┃                        [{name, status, icon, descriptions}, ...]     ┃
┃  created_at            TIMESTAMPTZ                                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                      PUBLIC.NOTIFICATIONS                             ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  id                    UUID (PK)                                     ┃
┃  prospect_id           UUID (FK → prospects.id) 🔗                   ┃
┃  project_type          TEXT                                          ┃
┃  prospect_name         TEXT                                          ┃
┃  project_name          TEXT                                          ┃
┃  count                 INTEGER (nombre de messages groupés)          ┃
┃  read                  BOOLEAN                                       ┃
┃  created_at            TIMESTAMPTZ                                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


═══════════════════════════════════════════════════════════════════════════
RELATIONS & CARDINALITÉS
═══════════════════════════════════════════════════════════════════════════

users (1) ──────────────── (N) prospects
  │                              │
  │                              ├───────── (N) appointments
  │                              ├───────── (N) calls
  │                              ├───────── (N) tasks
  │                              ├───────── (N) chat_messages
  │                              ├───────── (N) project_steps_status
  │                              ├───────── (N) project_infos
  │                              └───────── (N) notifications
  │
  ├──────────────── (N) appointments (assigned_user_id)
  ├──────────────── (N) calls (assigned_user_id)
  ├──────────────── (N) tasks (assigned_user_id)
  └──────────────── (1) users (manager_id) ← Hiérarchie


═══════════════════════════════════════════════════════════════════════════
ROW LEVEL SECURITY (RLS)
═══════════════════════════════════════════════════════════════════════════

┌────────────────────────────────────────────────────────────────────────┐
│  RÔLE              │  ACCÈS                                            │
├────────────────────┼───────────────────────────────────────────────────┤
│  Global Admin      │  ✅ Tous les prospects                            │
│                    │  ✅ Tous les utilisateurs                         │
│                    │  ✅ Toutes les données                            │
├────────────────────┼───────────────────────────────────────────────────┤
│  Manager           │  ✅ Ses prospects                                 │
│                    │  ✅ Prospects de son équipe                       │
│                    │  ✅ Données de son équipe                         │
├────────────────────┼───────────────────────────────────────────────────┤
│  Commercial        │  ✅ Ses prospects uniquement                      │
│                    │  ✅ Ses RDV, appels, tâches                       │
│                    │  ❌ Pas d'accès aux autres commerciaux            │
├────────────────────┼───────────────────────────────────────────────────┤
│  Client            │  ✅ Ses propres données                           │
│                    │  ✅ RDV partagés (share = TRUE)                   │
│                    │  ✅ Ses messages de chat                          │
│                    │  ❌ Pas d'accès aux autres clients                │
└────────────────────┴───────────────────────────────────────────────────┘


═══════════════════════════════════════════════════════════════════════════
INDEXES & PERFORMANCES
═══════════════════════════════════════════════════════════════════════════

🔍 Indexes créés pour optimiser :
  • Recherches par email, téléphone
  • Filtres par statut, rôle
  • Jointures (foreign keys)
  • Recherches dans les tags (GIN index)
  • Tri par date (appointments, calls, tasks)


═══════════════════════════════════════════════════════════════════════════
REAL-TIME SUBSCRIPTIONS
═══════════════════════════════════════════════════════════════════════════

📡 Tables avec Real-time activé :
  • chat_messages        → Messages instantanés
  • notifications        → Alertes admin en temps réel
  • client_notifications → Alertes client en temps réel
  • appointments         → Synchronisation agenda
  • prospects            → Mise à jour pipeline


═══════════════════════════════════════════════════════════════════════════
FONCTIONS SQL
═══════════════════════════════════════════════════════════════════════════

🛠️ Fonctions disponibles :

  1️⃣  get_manager_team_prospects(manager_uuid)
      → Retourne tous les prospects d'un manager (incluant sous-équipes)

  2️⃣  get_overdue_activities(user_uuid)
      → Compte les appels et tâches en retard pour un utilisateur

  3️⃣  update_updated_at_column()
      → Trigger automatique pour mettre à jour updated_at


═══════════════════════════════════════════════════════════════════════════
DONNÉES PAR DÉFAUT
═══════════════════════════════════════════════════════════════════════════

✅ Insérées automatiquement :
  • 5 types de projets (ACC, Autonomie, Centrale, Investissement, ProducteurPro)
  • 3 colonnes de pipeline (MARKET, ETUDE, OFFRE)
  • Paramètres de société (Locasun)


═══════════════════════════════════════════════════════════════════════════
LÉGENDE
═══════════════════════════════════════════════════════════════════════════

🔗  = Foreign Key (relation)
PK  = Primary Key
FK  = Foreign Key
(1) = Un seul
(N) = Plusieurs
```
