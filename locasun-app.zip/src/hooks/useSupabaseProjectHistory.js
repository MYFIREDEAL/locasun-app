import { useState, useEffect, useCallback } from "react";
import { supabase } from "../lib/supabase";

export function useSupabaseProjectHistory({ projectType, prospectId, enabled = true }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const fetchHistory = useCallback(async () => {
    if (!projectType || !enabled) return;

    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from("project_history")
        .select("*")
        .eq("project_type", projectType)
        .order("created_at", { ascending: false });

      if (prospectId) {
        query = query.eq("prospect_id", prospectId);
      }

      const { data, error } = await query;
      if (error) throw error;
      setHistory(data || []);

    } catch (err) {
      console.error("Error fetching project history:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [projectType, prospectId, enabled]);

  useEffect(() => {
    if (!projectType || !enabled) return;

    fetchHistory();

    const channel = supabase
      .channel(`project-history-${projectType}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "project_history",
          filter: `project_type=eq.${projectType}`,
        },
        (payload) => {
          setHistory((current) => [payload.new, ...current]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [projectType, enabled, fetchHistory]);


  const addHistoryEvent = useCallback(
    async ({ event_type, title, description, metadata, createdBy, createdByName }) => {
      if (!projectType || !event_type) return;

      try {
        setSaving(true);
        setError(null);

        const { data, error } = await supabase
          .from("project_history")
          .insert([
            {
              project_type: projectType,
              prospect_id: prospectId || null,
              event_type,
              title,
              description,
              metadata,
              created_by: createdBy || null,
              created_by_name: createdByName || null,
            },
          ])
          .select()
          .single();

        if (error) throw error;
        return data;

      } catch (err) {
        console.error("Error adding history event:", err);
        setError(err.message);
        throw err;
      } finally {
        setSaving(false);
      }
    },
    [projectType, prospectId]
  );

  // 🔥 AJOUT: Fonction simplifiée pour ajouter un événement projet
  const addProjectEvent = useCallback(
    async ({ prospectId, projectType, title, description, createdBy }) => {
      if (!projectType || !prospectId) {
        console.error('❌ [addProjectEvent] prospectId et projectType requis');
        return { success: false, error: 'Paramètres manquants' };
      }

      try {
        console.log('➕ [addProjectEvent] Ajout événement:', { prospectId, projectType, title });

        const { data, error } = await supabase
          .from("project_history")
          .insert([
            {
              project_type: projectType,
              prospect_id: prospectId,
              event_type: 'form_event', // Type générique pour formulaires
              title,
              description,
              created_by_name: createdBy || null,
            },
          ])
          .select()
          .single();

        if (error) {
          console.error('❌ [addProjectEvent] Erreur Supabase:', error.message);
          throw error;
        }

        console.log('✅ [addProjectEvent] Événement créé:', data.id);
        return { success: true, data };

      } catch (err) {
        console.error('❌ [addProjectEvent] Exception:', err.message || err);
        return { success: false, error: err.message || 'Erreur inconnue' };
      }
    },
    []
  );

  return {
    history,
    loading,
    saving,
    error,
    addHistoryEvent,
    addProjectEvent, // 🔥 AJOUT: Nouvelle fonction simplifiée
    refetch: fetchHistory,
  };
}
